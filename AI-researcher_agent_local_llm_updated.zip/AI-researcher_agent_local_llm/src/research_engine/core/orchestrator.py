"""Central research orchestrator.

The harness owns execution: state transitions, budgets, retries, checkpointing.
LLMs propose; the orchestrator decides and persists.
"""
from __future__ import annotations

import json
from pathlib import Path
import logging
import time
from datetime import datetime, timezone

from research_engine.core.budget import Budget
from research_engine.core.config import AppConfig
from research_engine.core.http_policy import build_egress_policy
from research_engine.core.state_machine import StateMachine
from research_engine.models.enums import (
    ProjectState, ReviewGate, StopReason, TaskStatus, TaskType,
)
from research_engine.models.project import ResearchMetrics, ResearchProject
from research_engine.models.task import Task
from research_engine.pipeline.clarification import ClarificationWorker
from research_engine.pipeline.documents import DocumentProcessor
from research_engine.pipeline.evidence import EvidenceWorker
from research_engine.pipeline.planning import PlannerWorker, QueryPlannerWorker, select_queries
from research_engine.pipeline.retrieval import RetrievalWorker
from research_engine.pipeline.routing import ProviderRegistry
from research_engine.reasoning.contradiction_detector import ContradictionDetector
from research_engine.reasoning.convergence import ConvergenceAnalyzer
from research_engine.reasoning.gap_detector import GapDetector
from research_engine.prompts.registry import record_versions
from research_engine.providers.llm.router import ModelRouter
from research_engine.storage.cache import KVCache
from research_engine.storage.database import Database
from research_engine.storage.events import EventLog
from research_engine.storage.repositories import Repositories
from research_engine.storage.workspace import Workspace

log = logging.getLogger(__name__)


class Orchestrator:
    def __init__(self, cfg: AppConfig, project: ResearchProject,
                 registry: ProviderRegistry | None = None):
        self.cfg = cfg
        self.project = project
        self.ws = Workspace(cfg.storage.data_dir, project.id)
        self.db = Database(self.ws.db_path)
        self.repos = Repositories(self.db)
        self.events = EventLog(self.ws.root, redact_secrets=self.cfg.platform.security.redact_secrets_in_logs)
        self.router = ModelRouter(cfg)
        self.registry = registry or build_default_registry(cfg)
        self.sm = StateMachine(self.repos)
        self.budget = Budget(cfg, project)
        self._stop_requested = False
        self._pause_requested = False
        self.trace_id = ""            # platform trace correlation (spec #50)

    # ------------------------------------------------------------------ setup
    @classmethod
    def create_project(
        cls,
        cfg: AppConfig,
        question: str,
        mode: str | None = None,
        cli_overrides: dict | None = None,
    ) -> "Orchestrator":
        mode = mode or cfg.research.mode
        from research_engine.core.ids import project_id_from_question
        from research_engine.engines.loader import get_engine, resolve_effective_config
        pid = project_id_from_question(question)
        ws_root = Path(cfg.storage.data_dir) / pid
        try:
            manifest = get_engine(mode, workspace_dir=ws_root)
            eff_cfg, provenance = resolve_effective_config(
                cfg, manifest, project_workspace=ws_root, cli_overrides=cli_overrides
            )
            eff_cfg.storage.data_dir = cfg.storage.data_dir
        except Exception:
            eff_cfg = cfg
            provenance = {}
        project = ResearchProject(id=pid, question_raw=question.strip(), mode=mode)
        project.ensure_id()
        orch = cls(eff_cfg, project)
        orch.project.config_snapshot = {
            "research": json.loads(eff_cfg.research.model_dump_json()),
            "resources": json.loads(eff_cfg.resources.model_dump_json()),
            "prompt_versions": record_versions(engine=mode, workspace_dir=ws_root),
            "models": {r: getattr(eff_cfg.models, r).model + "@" + getattr(eff_cfg.models, r).provider
                       for r in ("extractor", "reasoning", "synthesis")},
            "effective_provenance": provenance,
        }
        orch.repos.projects.save(orch.project)
        orch.ws.project_json.write_text(json.dumps(
            json.loads(orch.project.model_dump_json()), indent=2, default=str))
        orch.events.record(pid, "project_created", "orchestrator",
                           metadata={"mode": mode}, human_line=f"\n[{_ts()}] PROJECT CREATED {pid}\nQuestion: {question}")
        return orch

    @classmethod
    def load(
        cls,
        cfg: AppConfig,
        project_id: str,
        cli_overrides: dict | None = None,
    ) -> "Orchestrator":
        ws = Workspace(cfg.storage.data_dir, project_id)
        db = Database(ws.db_path)
        repos = Repositories(db)
        project = repos.projects.get(project_id)  # type: ignore[assignment]
        if project is None:
            raise FileNotFoundError(f"project not found: {project_id}")
        try:
            from research_engine.engines.loader import get_engine, resolve_effective_config
            manifest = get_engine(project.mode, workspace_dir=ws.root)
            eff_cfg, _ = resolve_effective_config(
                cfg, manifest, project_workspace=ws.root, cli_overrides=cli_overrides
            )
            eff_cfg.storage.data_dir = cfg.storage.data_dir
        except Exception:
            eff_cfg = cfg
        return cls(eff_cfg, project)

    def persist_checkpoint(self) -> None:
        self.project.updated_at = datetime.now(timezone.utc)
        self.repos.projects.save(self.project)
        self.ws.project_json.write_text(json.dumps(
            json.loads(self.project.model_dump_json()), indent=2, default=str))

    def request_stop(self) -> None:
        self._stop_requested = True

    def request_pause(self) -> None:
        """Cooperative pause: takes effect at the next phase boundary."""
        self._pause_requested = True

    def _check_pause(self) -> bool:
        """Returns True if a pause was requested and applied. The project is
        left in PAUSED state; resume() continues cleanly from the checkpoint."""
        if not self._pause_requested or self.project.state in (
                ProjectState.PAUSED, ProjectState.CONVERGED,
                ProjectState.COMPLETED, ProjectState.FAILED):
            return False
        self.sm.transition(self.project, ProjectState.PAUSED,
                           "paused by user/job control")
        self.events.record(self.project.id, "paused", "orchestrator",
                           metadata={"iteration": self.project.current_iteration},
                           human_line=f"[{_ts()}] PAUSED at iteration "
                                      f"{self.project.current_iteration}")
        self.persist_checkpoint()
        return True

    # ------------------------------------------------------------------ main loop
    def _build_loop_runner(self, max_iterations: int | None = None):
        from research_engine.engines.loader import get_engine
        from research_engine.engines.runner import LoopRunner
        try:
            manifest = get_engine(self.project.mode, workspace_dir=self.ws.root)
        except Exception:
            manifest = get_engine("academic")
        eff_max = max_iterations if max_iterations is not None else self.cfg.research.max_iterations
        return LoopRunner(
            manifest=manifest,
            project=self.project,
            state_machine=self.sm,
            on_checkpoint=self.persist_checkpoint,
            metrics_provider=self._compute_metrics,
            max_iterations=eff_max,
        )

    def run(self, max_iterations: int | None = None) -> ResearchProject:
        p = self.project
        try:
            runner = self._build_loop_runner(max_iterations=max_iterations)
            runner.run_orchestrated(self, max_iterations=max_iterations)
        except Exception as exc:
            log.exception("orchestrator failure")
            p.stop_reason = StopReason.FAILED
            try:
                self.sm.transition(p, ProjectState.FAILED, str(exc)[:300])
            except ValueError as trans_exc:
                log.error("state transition to FAILED rejected (%s); forcing FAILED state", trans_exc)
                self.project.state = ProjectState.FAILED
            self.events.record(p.id, "fatal_error", "orchestrator", status="error", error=str(exc)[:500],
                               human_line=f"[{_ts()}] FATAL: {exc}")
            self.persist_checkpoint()
            raise
        self.persist_checkpoint()
        return p

    def resume(self) -> ResearchProject:
        """Resume a paused/interrupted project from its persisted state."""
        p = self.project
        self._pause_requested = False
        gate = p.review_gate_pending
        if gate and gate not in p.approved_gates:
            p.approved_gates.append(gate)
        if p.state == ProjectState.PAUSED:
            if gate in (ReviewGate.AFTER_PROBLEM_DEFINITION.value, "WAITING_FOR_USER"):
                self.sm.transition(p, ProjectState.CLARIFYING, f"resumed after {gate}")
            elif gate == ReviewGate.AFTER_INITIAL_RESEARCH_PLAN.value:
                self.sm.transition(p, ProjectState.PLANNED, "resumed after initial research plan review")
            elif gate == ReviewGate.AFTER_FIRST_RESEARCH_CYCLE.value:
                self.sm.transition(p, ProjectState.GENERATING_FOLLOWUPS, "resumed after first research cycle review")
                self._generate_followups(p.current_iteration)
                p.current_iteration += 1
                self.events.record(
                    p.id, "iteration_begin", "orchestrator",
                    metadata={"iteration": p.current_iteration},
                    human_line=f"\n[{_ts()}] ITERATION {p.current_iteration}\n" + "-" * 40,
                )
                self.sm.transition(p, ProjectState.SEARCHING, f"iteration {p.current_iteration} begins")
            elif gate == ReviewGate.BEFORE_FINAL_SYNTHESIS.value:
                self.sm.transition(p, ProjectState.CONVERGED, "resumed before final synthesis")
            else:
                if p.current_iteration == 0:
                    if not self.repos.problems.all(p.id):
                        self.sm.transition(p, ProjectState.CLARIFYING, "resumed before clarification")
                    elif not self.repos.plans.all(p.id):
                        self.sm.transition(p, ProjectState.CLARIFYING, "resumed before planning")
                    else:
                        self.sm.transition(p, ProjectState.PLANNED, "resumed before first iteration")
                elif p.stop_reason is not None:
                    self.sm.transition(p, ProjectState.CONVERGED, "resumed converged project")
                else:
                    self.sm.transition(p, ProjectState.SEARCHING, f"resumed after gate {gate}")
        p.review_gate_pending = None
        self.repos.projects.save(p)
        return self.run()

    # ------------------------------------------------------------------ phases
    def _phase_clarify(self) -> None:
        p = self.project
        self.sm.transition(p, ProjectState.CLARIFYING, "start clarification")
        task = self._new_task(TaskType.CLARIFY_PROBLEM, 1.0)
        worker = ClarificationWorker(self.router.reasoning, self.repos)
        t0 = time.time()
        problem = worker.run(p.id, p.question_raw, p.mode)
        self._complete_task(task, {"problem_id": problem.id})
        self.events.record(p.id, "problem_clarified", "clarification", task.id,
                           duration_ms=(time.time() - t0) * 1000,
                           metadata={"subquestions": len(problem.subquestions),
                                     "assumptions": len(problem.assumptions)},
                           human_line=f"\n[{_ts()}] PROBLEM DEFINITION\nObjective: {problem.objective}\n"
                                      f"Subquestions: {len(problem.subquestions)}\n"
                                      + "\n".join(f"  - {a.text}" for a in problem.assumptions))
        try:
            from research_engine.engines.loader import get_engine
            from research_engine.pipeline.questions import generate_questions_for_project
            manifest = get_engine(p.mode, workspace_dir=self.ws.root)
            ask_step = next((s for s in manifest.loop.setup if s.step == "ask_user"), None)
            if ask_step is not None or manifest.tunables.ask_user_enabled or manifest.clarifier.required_inputs:
                blocking = (ask_step.blocking if ask_step is not None else False) or manifest.tunables.ask_user_blocking
                max_q = ask_step.max_questions if ask_step is not None else manifest.tunables.max_user_questions_per_run
                generate_questions_for_project(
                    p, problem, manifest, self.repos,
                    max_questions=max_q, blocking=blocking, state_machine=self.sm,
                )
                if p.state == ProjectState.PAUSED:
                    self.persist_checkpoint()
                    return
        except Exception as exc:
            log.warning("ask_user generation skipped: %s", exc)
        if not self._review_gate(ReviewGate.AFTER_PROBLEM_DEFINITION):
            return
        # stays in CLARIFYING until the plan is generated (_phase_plan)

    def _phase_plan(self) -> None:
        p = self.project
        task = self._new_task(TaskType.GENERATE_RESEARCH_PLAN, 0.95)
        problem = self.repos.problems.all(p.id)[0]
        planner = PlannerWorker(self.router.reasoning, self.repos, p.mode)
        plan = planner.run(p.id, problem)
        qp = QueryPlannerWorker(self.router.reasoning, self.repos)
        queries = qp.run(p.id, plan, iteration=0)
        self._complete_task(task, {"branches": len(plan.branches), "queries": len(queries)})
        self.events.record(p.id, "plan_created", "planning", task.id,
                           metadata={"branches": [b.category for b in plan.branches]},
                           human_line=f"\n[{_ts()}] RESEARCH PLAN ({len(plan.branches)} branches)\n"
                                      + "\n".join(f"  [{b.category}] {b.question[:90]}"
                                                  for b in sorted(plan.branches, key=lambda x: -x.importance)))
        if not self._review_gate(ReviewGate.AFTER_INITIAL_RESEARCH_PLAN):
            return
        self.sm.transition(p, ProjectState.PLANNED, "plan created")

    def _begin_iteration(self) -> None:
        p = self.project
        p.current_iteration += 1
        p.budget.iterations_used = max(p.budget.iterations_used, p.current_iteration - 1)
        it = p.current_iteration
        self.events.record(p.id, "iteration_begin", "orchestrator", metadata={"iteration": it},
                           human_line=f"\n[{_ts()}] ITERATION {it}\n" + "-" * 40)
        self.sm.transition(p, ProjectState.SEARCHING, f"iteration {it} begins")

    def _phase_search_fetch_extract(self) -> None:
        p = self.project
        it = p.current_iteration
        # 1. queries: initial (iter 1) or follow-ups generated at end of prior cycle
        queries = self.repos.queries.all(p.id, "executed=0", ())
        if not queries:
            queries = self._generate_followups(it)
            if not queries:
                p.stop_reason = StopReason.NO_HIGH_VALUE_GAPS
                self.sm.transition(p, ProjectState.CONVERGED, "no further queries worth running")
                return
        selected = select_queries(queries, min(
            self.cfg.research.max_queries_per_iteration, self.budget.queries_left()))
        # 2. search
        retrieval = RetrievalWorker(self.cfg, self.repos, self.registry, 
                                    KVCache(f"{self.cfg.storage.data_dir}/_global/search_cache.sqlite"))
        executed_q, new_sources = retrieval.execute_queries(p.id, selected, self.budget.queries_left())
        self.budget.spend_query(len(executed_q))
        sources_cap = self.budget.sources_left()
        if len(new_sources) > sources_cap:
            new_sources = new_sources[:sources_cap]
        self.budget.spend_sources(len(new_sources))
        # 3. fetch + parse + chunk
        self.sm.transition(p, ProjectState.FETCHING, "search done")
        proc = self._make_document_processor()
        docs_before = self.repos.documents.count(p.id)
        documents = proc.process_sources(p.id, new_sources, self.budget.documents_left())
        fetched_now = self.repos.documents.count(p.id) - docs_before
        self.budget.spend_document(max(0, fetched_now))
        # 4. extract evidence
        self.sm.transition(p, ProjectState.EXTRACTING, "documents processed")
        problem = self.repos.problems.all(p.id)[0]
        questions = "\n".join([problem.research_question] + problem.subquestions[:10])
        ev_worker = EvidenceWorker(self.cfg, self.router.extractor, self.repos)
        new_ev, rejected_ct = ev_worker.extract_from_documents(
            p.id, documents, questions, iteration=it)
        self.sm.transition(p, ProjectState.VERIFYING, "extraction done")
        # claim consolidation includes quote verification already applied per-item
        new_claims, dup_claims = ev_worker.consolidate_claims(p.id, new_ev, it)
        self._dup_claims_by_iter = getattr(self, "_dup_claims_by_iter", {})
        self._dup_claims_by_iter[it] = dup_claims
        # --- Phase 2: attribute evidence/claims to branches via query lineage ---
        q_branch = {}
        for q in self.repos.queries.all(p.id):
            if q.branch:
                q_branch[q.id] = q.branch
        for e in new_ev:
            if e.branch:
                continue
            src = self.repos.sources.get(e.source_id)
            for qid in (src.query_ids if src else []):
                if qid in q_branch:
                    e.branch = q_branch[qid]
                    self.repos.evidence.save(e)
                    break
        useful_by_query: dict[str, int] = {}
        for e in new_ev:
            src = self.repos.sources.get(e.source_id)
            for qid in (src.query_ids if src else []):
                useful_by_query[qid] = useful_by_query.get(qid, 0) + 1
        for q in executed_q:
            q.useful_results = useful_by_query.get(q.id, 0)
            self.repos.queries.save(q)

        self.events.record(p.id, "cycle_complete", "retrieval",
                           metadata={"queries": len(executed_q), "sources": len(new_sources),
                                     "docs_fetched": max(0, fetched_now), "evidence": len(new_ev),
                                     "evidence_rejected": rejected_ct, "new_claims": new_claims,
                                     "duplicate_claims": dup_claims},
                           status="ok" if new_sources else "empty",
                           human_line=(f"Queries executed: {len(executed_q)} | Sources found: {len(new_sources)} | "
                                       f"Docs parsed: {max(0, fetched_now)}\n"
                                       f"Evidence extracted: {len(new_ev)} (rejected: {rejected_ct}) | "
                                       f"New claims: {new_claims} (duplicates: {dup_claims})"))
        self.sm.transition(p, ProjectState.ANALYZING_GAPS, "verify done")

    def _phase_analyze(self) -> bool:
        """Returns True if another iteration should run."""
        p = self.project
        it = p.current_iteration
        gap_detector = GapDetector(self.router.reasoning, self.repos)
        problem = self.repos.problems.all(p.id)[0]
        plan = self.repos.plans.all(p.id)
        plan = plan[-1] if plan else None
        gaps = gap_detector.run(p.id, plan, problem, it, mode=p.mode)
        con_detector = ContradictionDetector(self.router.reasoning, self.repos)
        contradictions = con_detector.run(p.id)

        # --- Phase 2: graph + strength aggregation + adversarial analysis ---
        from research_engine.pipeline.graph_builder import GraphBuilder
        from research_engine.storage.graph_store import GraphStore
        from research_engine.reasoning.evidence_quality import ClaimStrengthService
        from research_engine.reasoning.adversarial import AdversarialEngine
        from research_engine.reasoning.contradiction_analyzer import ContradictionAnalyzer
        from research_engine.reasoning.priority import BranchCoverageModel

        if not hasattr(self, "_graph"):
            self._graph = GraphStore(self.db)
        try:
            gstats = GraphBuilder(self.repos, self._graph).rebuild(p.id)
        except Exception as exc:  # graph problems never kill the loop
            log.warning("graph build failed (isolated): %s", exc)
            gstats = {}
        ClaimStrengthService(self.repos).refresh(p.id)
        adv_gaps = []
        try:
            _, adv_gaps = AdversarialEngine(self.repos).build_challenges(p.id)
        except Exception as exc:
            log.warning("adversarial analysis failed (isolated): %s", exc)
        for g in adv_gaps:
            if not any(x.description[:60] == g.description[:60]
                       for x in self.repos.gaps.all(p.id)):
                g.ensure_id()
                self.repos.gaps.save(g)
                gaps.append(g)
        for con_id, assessment in ContradictionAnalyzer(self.repos).assess_all(p.id):
            con = self.repos.contradictions.get(con_id)
            if con is not None and assessment.verdict != "UNRESOLVED":
                con.explanation = f"[{assessment.verdict}] {con.explanation}"[:400]
                self.repos.contradictions.save(con)

        # coverage snapshot on branches
        if plan is not None:
            coverage = BranchCoverageModel(self.repos).compute(p.id, plan.branches)
            for b in plan.branches:
                cov = coverage.get(b.id)
                if cov:
                    b.coverage_score = cov["coverage"]
                    b.evidence_count = cov["evidence_count"]
                    b.gap_count = cov["gap_count"]
                    b.status = ("answered" if cov["answered"] else
                                "partially_answered" if cov["weakly_answered"] else "open")
                    self.repos.branches.save(b)

        metrics = self._compute_metrics(it)
        self.repos.metrics.save(metrics)
        # research gain vs previous iteration
        prev_metrics = [m for m in self.repos.metrics.all(p.id) if m.iteration == it - 1]
        gain = self._research_gain(prev_metrics[0], metrics) if prev_metrics else None
        metrics.gap_resolution_rate = round(
            metrics.gaps_resolved / max(1, metrics.gaps_resolved + metrics.gaps_open), 3)

        decision = ConvergenceAnalyzer(self.cfg, self.router.reasoning).evaluate(p, self.budget, {
            "objective": problem.objective, "iteration": it,
            "total_evidence": self.repos.evidence.count(p.id, "status!='REJECTED'"),
            "new_evidence": metrics.new_evidence_this_iter,
            "new_claims": metrics.new_claims_this_iter,
            "duplicate_rate": metrics.duplicate_rate,
            "rejection_rate": metrics.rejection_rate,
            # P0-04: the degradation signal is "retrieval was attempted and
            # FAILED" — search failures plus fetch failures.
            # The old test was `fetch_failures > 0 and queries_executed > 0`,
            # which could never fire: a fetch failure marks the SOURCE row
            # (not a document), so `documents_failed` is always 0, and
            # `queries_executed` is 0 in the executing iteration.
            "retrieval_failures": (max(0, metrics.search_failures - (prev_metrics[0].search_failures if prev_metrics else 0))
                                   + max(0, metrics.sources_rejected - (prev_metrics[0].sources_rejected if prev_metrics else 0))),
            "high_importance_gaps": len([g for g in gaps if not g.resolved and g.importance >= 0.6]),
            "domains": metrics.source_diversity_domains,
        })
        high_gaps = len([g for g in gaps if not g.resolved and g.importance >= 0.6])
        self.events.record(p.id, "analysis_complete", "reasoning",
                           metadata={"gaps_open": len([g for g in gaps if not g.resolved]),
                                     "contradictions_new": len(contradictions),
                                     "graph": gstats,
                                     "research_gain": gain,
                                     "stop_decision": decision.stop_reason.value if decision.should_stop else "continue"},
                           human_line=(f"Gaps open: {len([g for g in gaps if not g.resolved])} "
                                       f"(high-priority: {high_gaps}) | Contradictions total: "
                                       f"{self.repos.contradictions.count(p.id)}\n"
                                       + (f"Research gain this iteration: {gain:+d}\n" if gain is not None else "")
                                       + "\n".join(f"  GAP [{g.category.value}] {g.description[:100]}"
                                                   for g in sorted(gaps, key=lambda x: -x.importance)[:5])))
        p.budget.iterations_used = it
        if decision.should_stop:
            p.stop_reason = decision.stop_reason
            self.persist_checkpoint()
            if p.stop_reason in (StopReason.CONVERGED, StopReason.NO_HIGH_VALUE_GAPS):
                stop_expl = self._stop_explanation(gains_history=None, last_rationale=decision.rationale,
                                                   high_gaps=high_gaps)
                self.events.record(p.id, "stop_policy_applied", "orchestrator",
                                   metadata={"explanation": stop_expl},
                                   human_line=f"Stopping policy: {stop_expl}")
                self.sm.transition(p, ProjectState.CONVERGED, stop_expl)
            else:
                self.sm.transition(p, ProjectState.GENERATING_FOLLOWUPS, decision.rationale)
                label = ("provider degraded -> synthesis (results flagged, "
                         "NOT converged)" if p.stop_reason == StopReason.PROVIDER_DEGRADED
                         else "budget stop -> synthesis")
                self.sm.transition(p, ProjectState.CONVERGED, f"{label}: {decision.rationale}"[:200])
            return False
        if it >= (self.cfg.research.max_iterations):
            p.stop_reason = StopReason.MAX_ITERATIONS
            expl = self._stop_explanation(None, "max iterations reached", high_gaps)
            self.events.record(p.id, "stop_policy_applied", "orchestrator",
                               metadata={"explanation": expl},
                               human_line=f"Stopping policy: {expl}")
            self.sm.transition(p, ProjectState.CONVERGED, expl)
            return False
        if it == 1:
            if not self._review_gate(ReviewGate.AFTER_FIRST_RESEARCH_CYCLE):
                return False
        self.sm.transition(p, ProjectState.GENERATING_FOLLOWUPS, "gaps remain")
        self._generate_followups(it)
        p.current_iteration += 1
        self.events.record(p.id, "iteration_begin", "orchestrator",
                           metadata={"iteration": p.current_iteration},
                           human_line=f"\n[{_ts()}] ITERATION {p.current_iteration}\n" + "-" * 40)
        self.sm.transition(p, ProjectState.SEARCHING, f"iteration {p.current_iteration} begins")
        return True

    @staticmethod
    def _research_gain(prev, cur) -> int:
        """Research gain per iteration (spec #88, P3-2): supported claims + resolved gaps
        + deduplicated accepted evidence delta; duplicate quote re-ingestions add 0 gain."""
        raw_ev_accepted = max(0, ((cur.evidence_created - cur.evidence_rejected)
                                  - (prev.evidence_created - prev.evidence_rejected)))
        dedup_ev_accepted = max(
            0.0,
            raw_ev_accepted * (1.0 - max(0.0, min(1.0, float(getattr(cur, "duplicate_rate", 0.0))))),
        )
        new_claims = cur.new_claims_this_iter
        gaps_resolved = max(0, cur.gaps_resolved - prev.gaps_resolved)
        quality_uplift = max(0.0, cur.source_diversity_domains - prev.source_diversity_domains)
        return int(round(new_claims * 2 + gaps_resolved * 2
                         + dedup_ev_accepted * 0.5 + quality_uplift))

    def _stop_explanation(self, gains_history, last_rationale: str,
                          high_gaps: int) -> str:
        """Explicit, honest stop explanation (spec #106/#125)."""
        if high_gaps > 0 and self.budget.exhausted():
            return ("Research stopped due to budget exhaustion while "
                    f"{high_gaps} high-priority gaps remain unresolved.")
        if high_gaps == 0:
            return ("Research stopped because no high-importance gaps remain open "
                    "and recent iterations produced minimal new evidence.")
        return f"Research stopped ({last_rationale}); {high_gaps} high-priority gaps remain."

    def _generate_followups(self, it: int) -> list:
        """Adaptive planner decides what to research next (Phase 2 'what next?' engine)."""
        p = self.project
        plan = self.repos.plans.all(p.id)
        plan = plan[-1] if plan else None
        if plan is None:
            return []
        problem = self.repos.problems.all(p.id)[0]
        budget = min(self.cfg.research.max_queries_per_iteration,
                     self.budget.queries_left())
        try:
            from research_engine.reasoning.adaptive_planner import AdaptivePlanner
            step = AdaptivePlanner(self.router.reasoning, self.repos).plan_next(
                p.id, problem, plan, iteration=it, budget_queries=max(1, budget))
            created = list(step.queries)
            self.events.record(p.id, "adaptive_plan", "planning",
                               metadata={"strategy": step.strategy, "reason": step.reason,
                                         "queries": len(created)},
                               human_line=(f"Strategy: {step.strategy} — {step.reason}\n"
                                           + "\n".join(f"  + {q.text[:80]}" for q in created[:6])))
        except Exception as exc:
            log.warning("adaptive planner failed; falling back to legacy followups: %s", exc)
            created = []
            qp = QueryPlannerWorker(self.router.reasoning, self.repos)
            created = qp.run(p.id, plan, iteration=it, per_branch=3)
        # add gap-recommended and contradiction follow-up queries directly
        from research_engine.models.research import SearchQuery
        for g in self.repos.gaps.all(p.id, "resolved=0 AND importance>=0.55", ()):
            for rq in g.recommended_queries[:2]:
                q = SearchQuery(project_id=p.id, text=rq.text, branch=g.branch,
                                reason=f"gap {g.id}: {rq.reason}", kind="primary",
                                priority=g.importance, expected_information_gain=g.importance,
                                iteration=it)
                if not any(x.text == q.text for x in self.repos.queries.all(p.id)):
                    q.ensure_id()
                    self.repos.queries.save(q)
                    created.append(q)
        for c in self.repos.contradictions.all(p.id, "resolved=0", ()):
            if c.follow_up_query:
                q = SearchQuery(project_id=p.id, text=c.follow_up_query, reason=f"contradiction {c.id}",
                                kind="contradiction", priority=0.8,
                                expected_information_gain=0.8, iteration=it)
                if not any(x.text == q.text for x in self.repos.queries.all(p.id)):
                    q.ensure_id()
                    self.repos.queries.save(q)
                    created.append(q)
        return created

    def _phase_synthesize(self) -> None:
        from research_engine.reports.generator import ReportGenerator
        p = self.project
        self.sm.transition(p, ProjectState.SYNTHESIZING, "converged; generating reports")
        # --- Phase 3: reasoning layer over the evidence graph ---
        try:
            from research_engine.storage.reasoning_repos import ReasoningRepos
            from research_engine.reasoning.pipeline import ReasoningPipeline
            if not hasattr(self, "_rrepos"):
                self._rrepos = ReasoningRepos(self.db)
            pipe = ReasoningPipeline(self.repos, self._rrepos,
                                     self.router.reasoning, self.registry)
            try:
                from research_engine.engines.loader import get_engine
                _specialist = get_engine(p.mode).analysis.specialist_pipeline
            except Exception:
                _specialist = "startup" if p.mode == "startup" else None
            if _specialist == "startup":
                # P0-12: single canonical pipeline. No legacy fallback —
                # a specialist failure is surfaced honestly (warning + event)
                # instead of silently double-writing via the retired engine.
                try:
                    from research_engine.specialists.startup.service import (
                        StartupResearchService)
                    svc = StartupResearchService(cfg=self.cfg,
                                                 data_dir=self.cfg.storage.data_dir)
                    spipe = svc.run_full_pipeline(p.id)
                    n_opp = spipe.get("discovery", {}).get("count", 0)
                    n_tests = sum(len(pl.get("tests_designed", []))
                                  for pl in spipe.get("validation", {}).get("plans", []))
                    self._startup_pipeline_result = spipe
                    self.events.record(
                        p.id, "startup_pipeline_complete", "reasoning",
                        metadata={"opportunities": n_opp, "validation_tests": n_tests},
                        human_line=(f"Startup specialist: {n_opp} evidence-gated "
                                    f"opportunities, {n_tests} validation tests designed"))
                except Exception as exc:
                    log.warning("startup pipeline failed (isolated): %s", exc)
                    self.events.record(
                        p.id, "startup_pipeline_failed", "reasoning",
                        metadata={"error": str(exc)[:300]},
                        human_line=(f"[WARN] startup specialist failed: "
                                    f"{str(exc)[:160]}"))
            else:
                rsum = pipe.run_for_project(p.id, mode=p.mode)
                self.events.record(p.id, "hypotheses_generated", "reasoning",
                                   metadata={"count": len(rsum.get("generated", [])),
                                             "top": rsum.get("ranked", [])[:3]},
                                   human_line=("Hypothesis engine: "
                                               f"{len(rsum.get('generated', []))} competing hypotheses "
                                               "generated from top gaps/contradictions"))
        except Exception as exc:
            log.warning("reasoning pipeline failed (isolated): %s", exc)
        gen = ReportGenerator(self.cfg, self.router.synthesis, self.repos, self.ws)
        generated = gen.generate_all(p)
        from research_engine.models.project import ResearchReport
        now_iso = datetime.now(timezone.utc).isoformat()
        existing_by_path = {r.path: r for r in self.repos.reports.all(p.id)}
        for rname in generated:
            rep = existing_by_path.get(rname) or ResearchReport(
                project_id=p.id,
                kind=rname.removesuffix(".md"),
                path=rname,
            )
            rep.generated_at = now_iso
            rep.stop_reason = p.stop_reason
            rep.budget_limited = bool(p.stop_reason and p.stop_reason != StopReason.CONVERGED)
            rep.ensure_id()
            self.repos.reports.save(rep)
        try:
            from research_engine.memory.relational_kb import RelationalKnowledgeBase
            RelationalKnowledgeBase(self.cfg.storage.data_dir).ingest_from_project(p.id, self.repos)
        except Exception as exc:
            log.warning("relational_kb ingest skipped (isolated): %s", exc)
        self.sm.transition(p, ProjectState.COMPLETED, f"reports: {', '.join(generated)}")
        self.events.record(p.id, "reports_generated", "reports",
                           metadata={"reports": generated},
                           human_line=(f"\n[{_ts()}] RESEARCH {'CONVERGED' if p.stop_reason == StopReason.CONVERGED else 'STOPPED'} "
                                       f"({p.stop_reason.value if p.stop_reason else '?'})\n"
                                       f"Reports written to {self.ws.reports}:\n"
                                       + "\n".join(f"  - {r}" for r in generated)))

    # ------------------------------------------------------------------ helpers
    def _compute_metrics(self, it: int) -> ResearchMetrics:
        p = self.project
        m = ResearchMetrics(project_id=p.id, iteration=it)
        m.sources_accepted = self.repos.sources.count(p.id, "status='PARSED'")
        m.sources_rejected = self.repos.sources.count(p.id, "status='FAILED'")
        m.sources_discovered = self.repos.sources.count(p.id)
        m.documents_fetched = self.repos.documents.count(p.id, "status='PARSED'")
        m.documents_failed = self.repos.documents.count(p.id, "status!='PARSED'")
        m.evidence_created = self.repos.evidence.count(p.id)
        m.evidence_rejected = self.repos.evidence.count(p.id, "status='REJECTED'")
        m.unique_claims = self.repos.claims.count(p.id)
        dup_by_iter = getattr(self, "_dup_claims_by_iter", {})
        prev_dup_total = sum(
            getattr(pm, "duplicate_claims_this_iter", 0)
            for pm in self.repos.metrics.all(p.id) if pm.iteration < it
        )
        m.duplicate_claims_this_iter = int(dup_by_iter.get(it, 0))
        m.duplicate_claims = prev_dup_total + m.duplicate_claims_this_iter
        m.contradictions = self.repos.contradictions.count(p.id)
        m.gaps_open = self.repos.gaps.count(p.id, "resolved=0")
        m.gaps_resolved = self.repos.gaps.count(p.id, "resolved=1")
        # per-iteration deltas come straight from iteration stamps on entities
        cur_ev_total = self.repos.evidence.count(p.id, "status!='REJECTED'")
        m.new_evidence_this_iter = self.repos.evidence.count(
            p.id, f"iteration={it} AND status!='REJECTED'")
        m.new_claims_this_iter = self.repos.claims.count(p.id, f"iteration={it}")
        # P0-04: honest metric semantics — rejection ≠ duplication
        m.rejection_rate = round(self.repos.evidence.rejected_ratio(p.id), 3)
        m.duplicate_rate = round(self.repos.evidence.duplicate_ratio(p.id), 3)
        m.queries_this_iter = len([q for q in self.repos.queries.all(p.id, "executed=1", ())
                                   if q.iteration == it])
        # P0-04: a failed retrieval must be countable. `failed` is a JSON-only
        # field (like `results_count`), so it is counted in Python, not SQL.
        m.search_failures = len([q for q in self.repos.queries.all(p.id, "executed=1", ())
                                 if q.failed])
        m.new_evidence_rate = round(m.new_evidence_this_iter / max(1, cur_ev_total), 3)
        m.gap_resolution_rate = round(m.gaps_resolved / max(1, m.gaps_resolved + m.gaps_open), 3)
        parsed_sources = self.repos.sources.all(p.id, "status='PARSED'")
        domains = {s.domain for s in parsed_sources}
        m.source_diversity_domains = len(domains)
        tiers: dict[int, int] = {}
        for s in parsed_sources:
            tiers[s.source_tier] = tiers.get(s.source_tier, 0) + 1
        m.tier_distribution = {str(k): v for k, v in sorted(tiers.items())}
        m.llm_calls = (self.router.extractor.calls + self.router.reasoning.calls
                       + getattr(self.router.synthesis, "calls", 0))
        return m

    def _make_document_processor(self) -> DocumentProcessor:
        return DocumentProcessor(self.cfg, self.repos, self.ws)

    def _new_task(self, ttype: TaskType, priority: float) -> Task:
        t = Task(project_id=self.project.id, type=ttype, priority=priority,
                 iteration=self.project.current_iteration)
        t.ensure_id()
        self.repos.tasks.save(t)
        return t

    def _complete_task(self, task: Task, output: dict) -> None:
        task.status = TaskStatus.DONE
        task.output = output
        self.repos.tasks.save(task)

    def _review_gate(self, gate: ReviewGate) -> bool:
        """Returns True to continue. Pauses when review gates are enabled."""
        if not self.cfg.research.review_gates_enabled:
            return True
        p = self.project
        if gate.value in p.approved_gates:
            return True
        p.review_gate_pending = gate.value
        self.sm.transition(p, ProjectState.PAUSED, f"review gate {gate.value}")
        self.persist_checkpoint()
        self.events.record(p.id, "review_gate", "orchestrator",
                           metadata={"gate": gate.value},
                           human_line=f"\n[{_ts()}] PAUSED AT REVIEW GATE: {gate.value}\n"
                                      "Run 'research resume' after reviewing.")
        log.info("paused at review gate %s", gate.value)
        return False


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def build_default_registry(cfg: AppConfig) -> ProviderRegistry:
    reg = ProviderRegistry()
    policy = build_egress_policy(cfg)
    # Under LOCAL_ONLY no network provider is constructed - the policy
    # refuses every non-loopback host at construction time. This is the
    # single gating point: providers are never built here if egress is
    # denied, so they can never silently call out.
    if policy.strict:
        return reg
    from research_engine.providers.academic.arxiv import ArxivProvider
    from research_engine.providers.academic.crossref import CrossrefProvider
    from research_engine.providers.academic.openalex import OpenAlexProvider
    from research_engine.providers.academic.semantic_scholar import SemanticScholarProvider
    from research_engine.providers.search.duckduckgo import DuckDuckGoProvider, SearxngProvider
    timeout = cfg.network.timeout_seconds
    if cfg.search.web_provider == "duckduckgo":
        reg.register_search("web", DuckDuckGoProvider(timeout=timeout, policy=policy))
    elif cfg.search.web_provider == "searxng" and cfg.search.searxng_base_url:
        reg.register_search("web", SearxngProvider(cfg.search.searxng_base_url, timeout, policy=policy))
    # web_provider == "none" -> offline: no web search registered (#98/#100)
    providers = {
        "openalex": OpenAlexProvider(timeout=timeout, policy=policy),
        "crossref": CrossrefProvider(timeout=timeout, policy=policy),
        "arxiv": ArxivProvider(timeout=timeout, policy=policy),
        "semantic_scholar": SemanticScholarProvider(cfg.search.semantic_scholar_api_key, timeout, policy=policy),
    }
    for name in cfg.search.academic_providers:
        if name in providers:
            reg.register_academic(name, providers[name])
    return reg
